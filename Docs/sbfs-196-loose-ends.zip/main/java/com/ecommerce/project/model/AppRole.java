package com.ecommerce.project.model;

public enum AppRole {
    ROLE_USER,
    ROLE_SELLER,
    ROLE_ADMIN
}
